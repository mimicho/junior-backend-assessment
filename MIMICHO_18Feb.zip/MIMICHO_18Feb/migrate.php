
<?php 

include 'config.php';
$migrate_productcode='';
$migrate_productname='';

	
		$query="SELECT * FROM original_data";

		if ($result=mysqli_query($con,$query))
		{
		  		
		    while ($row = mysqli_fetch_array($result)) 
		    {

		    	$migrate_productname = $row['product_label'];

			    if($row['gender'] == 'M' or $row['gender'] == 'm')
			    { 	$migrate_productcode = 'men'.'_'.$row['product_code'];  }
			    else{  	$migrate_productcode = 'women'.'_'. $row['product_code'];   }

			   

			    
			    // check duplicate data before migrating 

			    $migrate_table_sql =" SELECT * FROM migrated_data where sku LIKE '$migrate_productcode' ";
			    $duplicate_result =mysqli_query($con, $migrate_table_sql);
				$duplicate_row_count = mysqli_num_rows($duplicate_result);


				    if($duplicate_row_count > 0) { echo "Record exist!";	} 
							
					else {
							
							$migrate_query = "INSERT INTO migrated_data (sku, name) VALUES ('$migrate_productcode', '$migrate_productname ')";
						    
						    if (mysqli_query($con, $migrate_query)) {
							    echo "New record created successfully <br>";
							} else {
							    echo "Error: " . $migrate_query . "<br>" . mysqli_error($conn);
							}
					}

  			}
		}    


mysqli_close($con);

?>


