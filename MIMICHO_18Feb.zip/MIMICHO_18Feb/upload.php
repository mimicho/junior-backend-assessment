<?php

include 'config.php';

$errors         = array();      // array to hold validation errors
$data           = array();      // array to pass back data

// if(isset($_POST["submit"])) {

	$skucode = $_POST['product_skucode'];
	$target_dir = "media/";
	$target_file = $target_dir . basename($_FILES["product_image"]["name"]);
	

	
	if (file_exists($target_file)) {
	    echo 'Sorry, Image Name already exists.';

	}
	

	else{


				$query =" SELECT * FROM migrated_data where sku LIKE '$skucode' ";
			    
				$result =mysqli_query($con, $query);
				$row_count = mysqli_num_rows($result);


				if($row_count == 0) { 
					echo "Record does not exist! Please use another sku code";	
					
				} 

			    else 
			    {
					
		    		$update_query = "UPDATE `migrated_data` SET `image_url` = '$target_file' WHERE sku LIKE '$skucode'";

				    if (mysqli_query($con, $update_query)) {
					    
					    	move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file);
						    echo "Product image:".basename( $_FILES["product_image"]["name"]). " has been uploaded in the record.";
						  
					} 

				    
				} 
						
		


		}
	
	


// }

?>