-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2019 at 04:53 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mindarc_assessment`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrated_data`
--

CREATE TABLE `migrated_data` (
  `product_id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migrated_data`
--

INSERT INTO `migrated_data` (`product_id`, `sku`, `name`, `image_url`) VALUES
(1, 'men_red_shirt', 'Mens Red Shirt ', 'media/bird.jpg'),
(2, 'women_red_blouse', 'Womens Red Blouse ', 'media/bridge.jpg'),
(3, 'men_blue_shorts', 'Mens Blue Shorts ', 'media/FIELD.jpg'),
(4, 'women_blue_skirt', 'Womens Blue Skirt ', 'media/dog.jpg'),
(5, 'women_rainbow_singlet', 'Singlet in Rainbow Colours ', 'media/cloud.jpg'),
(6, 'women_sun_one', 'Aviator Sunglasses ', 'media/road.jpg'),
(7, 'women_gold_neck', 'Gold Necklace Chain ', 'media/coffee.jpg'),
(8, 'women_iph_case', 'Iphone Case pink ', 'media/tiger.jpg'),
(9, 'men_sam_case', 'Samsung Case Skulls ', 'media/mountain.jpg'),
(10, 'men_black_shirt', 'AC/DC Shirt ', 'media/wood.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `original_data`
--

CREATE TABLE `original_data` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_label` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `original_data`
--

INSERT INTO `original_data` (`product_id`, `product_code`, `product_label`, `gender`) VALUES
(1, 'red_shirt', 'Mens Red Shirt', 'm'),
(2, 'red_blouse', 'Womens Red Blouse', 'f'),
(3, 'blue_shorts', 'Mens Blue Shorts', 'm'),
(4, 'blue_skirt', 'Womens Blue Skirt', 'f'),
(5, 'rainbow_singlet', 'Singlet in Rainbow Colours', 'v'),
(6, 'sun_one', 'Aviator Sunglasses', 'f'),
(7, 'gold_neck', 'Gold Necklace Chain', ''),
(8, 'iph_case', 'Iphone Case pink', 'F'),
(9, 'sam_case', 'Samsung Case Skulls', 'M'),
(10, 'black_shirt', 'AC/DC Shirt', 'm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrated_data`
--
ALTER TABLE `migrated_data`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `original_data`
--
ALTER TABLE `original_data`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrated_data`
--
ALTER TABLE `migrated_data`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
